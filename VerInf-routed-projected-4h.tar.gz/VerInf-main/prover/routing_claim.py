"""RoutingClaim + FreivaldsCombineClaim: verified top-1 MoE routing (Llama-4 style).

RoutingClaim proves that a committed one-hot mask `m` (T, E) selects the
argmax expert of committed router logits `r` (T, E), with ties broken by
lowest expert index, and recovers the chosen logit `r_chosen` for the
downstream sigmoid routing weight. It is the top-1 specialization of the
threshold gadget in design-feasibility.md §3.6 / appendix-moe-routing.md §B.3,
structured as a clone of the audited MaxClaim pattern: for topk = 1 the
threshold τ degenerates and "m is the top-1" is exactly "m is the one-hot
argmax", checked by gap ≥ 0 on tiebroken logits.

Tiebroken logits (appendix §B.3 (1)):  rt[t,e] = 2^L·r[t,e] + (E−1−e),
L = ceil(log2 E). All rt in a row are distinct, so the argmax — and hence m —
is unique, matching torch.topk / llama.cpp's lowest-index tie behavior.

Constraint families (emission order is load-bearing for the Rust verifier):
  F1  rt − 2^L·r = (E−1−e)            linear, RHS bonus pattern   (T·E)
  F2  Σ_e m[t,e] = 1                  cardinality, RHS 1          (T)
  F3  Σ_e mrt[t,e] − rstar[t] = 0     chosen tiebroken logit      (T)
  F4  gap + rt − rstar(bcast) = 0     dominance gap               (T·E)
  F5  2^L·r_chosen + Σ_e (E−1−e)·m[t,e] − rstar = 0               (T)
  Q1  m·m = m                         booleanity                  (T·E)
  Q2  m·rt = mrt                                                  (T·E)

gap ∈ [0, 2^{B+L}) is NOT checked here — the route_top1 builder composes the
existing tape.word_extract (WordExtractionClaim + RangeWordClaim) on the gap
output. Soundness precondition (documented in CLAIM_SPECS): `r` must already
be range-bounded to ±2^{B−1} by its producing matmul's output_width rescale;
the word width must satisfy N·B_word ≥ B+L and 2^{N·B_word+1} ≪ P.

Why a wrong mask cannot pass: booleanity + cardinality force a one-hot; if it
selects e' ≠ argmax(rt), then gap[argmax] = rt[e'] − rt[argmax] < 0, whose
field representative is ≈ P and cannot decompose into N·B_word ≪ 64 bits, so
the word-extraction linear constraint (or the word range LogUp) rejects.

FreivaldsCombineClaim proves y[t,:] = Σ_e m[t,e] · X_e[t,:] — the masked expert
combine (appendix §B.4 seam, all-experts-commit form) — by a random projection
ρ ∈ F^F instead of committing the E·T·F per-expert products: it collapses each
expert stream to a per-token scalar and checks the projected identity per token
(witness ~4·E·T, not ~2·E·T·F; soundness error ~1/|F| per token, sound under the
commit-before-challenge ordering). Its constraints (C1–C5 + the ms quadratic)
are documented at the claim below.
"""
import math
from dataclasses import dataclass
from typing import List, Tuple

import torch

import core
from core import (P, Variable, LigeroConfig, SAMPLE_FNS, AUX_FNS,
                  BIND_SAMPLE_FNS, AUX3_FNS, BIND_COMPILE_FNS)
from claims import (COMPILE_FNS, QuadraticConstraint, QuadFamily, L2_IdentityScalar,
                    L2_RowSumPerSlotVector, L2_StrideOneToManyScalar,
                    L2_StrideManyToOneScalar, L2_FreivaldsLF1B,
                    L2_FreivaldsLF2A, L2_FreivaldsLF3C, _build_b_chunk)
from packets import L2_TransposeO2MScalar
import compute_fns as _cf
from cuda_primitives import gl_mul, gl_add, gl_sub, gl_inv_batched, gl_matmul, gl_matvec
from max_claim import to_signed


# ===========================================================================
# RoutingClaim
# ===========================================================================

@dataclass
class RoutingClaim:
    r: Variable            # router logits (T*E), committed by the caller
    m: Variable            # one-hot top-1 mask (T*E), committed
    rt: Variable           # tiebroken logits 2^L·r + (E−1−e) (T*E), derived
    mrt: Variable          # m·rt (T*E), derived
    rstar: Variable        # chosen tiebroken logit per token (T), derived
    gap: Variable          # rstar − rt ≥ 0 (T*E), derived (range via word_extract)
    r_chosen: Variable     # chosen raw logit per token (T), derived (sigmoid input)
    T: int
    E: int
    L_bits: int            # ceil(log2 E), public

    @property
    def length(self):
        return self.T * self.E


def _bonus_vec(E: int) -> torch.Tensor:
    """Tiebreaker bonus (E−1−e) for e in [0, E) — uint64 cuda."""
    return (torch.arange(E - 1, -1, -1, dtype=torch.int64, device="cuda")
            .to(torch.uint64))


def routing_sample(c: RoutingClaim, ci, s_op):
    return None                      # no per-claim challenges


def routing_aux(c: RoutingClaim, witness, _ch):
    return {}                        # range LogUp aux lives in the composed word_extract


def routing_compute(c: RoutingClaim, live):
    """Derives EVERYTHING from r, including the mask: m = one-hot argmax of the
    tiebroken logits (signed comparison; first-max index matches torch.topk /
    llama.cpp ties). The engine computes r before this claim runs, so no
    build-time hint is needed. Downstream values derive from the (possibly
    TEST_TAMPER-overridden) mask so each negative test fires exactly its own
    constraint family."""
    T, E, Lb = c.T, c.E, c.L_bits
    r = live[c.r].contiguous().view(-1)
    two_l = torch.full((T * E,), 1 << Lb, dtype=torch.uint64, device="cuda")
    bonus = _bonus_vec(E).repeat(T)
    rt = gl_add(gl_mul(r, two_l), bonus)
    am = to_signed(rt).view(T, E).argmax(dim=1)
    ar = torch.arange(T, device="cuda")
    m = torch.zeros(T, E, dtype=torch.int64, device="cuda")
    m[ar, am] = 1
    m = m.to(torch.uint64)
    if "m" in TEST_TAMPER:
        m = TEST_TAMPER["m"].to("cuda").view(T, E)
    mrt = gl_mul(m.reshape(-1), rt)
    idx = m.view(torch.int64).argmax(dim=1)
    rstar = rt.view(torch.int64).view(T, E)[ar, idx].contiguous().view(torch.uint64)
    rs_bc = rstar.view(T, 1).expand(T, E).contiguous().reshape(-1)
    gap = gl_sub(rs_bc, rt)
    r_chosen = r.view(torch.int64).view(T, E)[ar, idx].contiguous().view(torch.uint64)
    outs = {c.m: m.reshape(-1), c.rt: rt, c.mrt: mrt, c.rstar: rstar,
            c.gap: gap, c.r_chosen: r_chosen}
    return _apply_tamper(outs, [("rt", c.rt), ("mrt", c.mrt), ("rstar", c.rstar),
                                 ("gap", c.gap), ("r_chosen", c.r_chosen)])


def routing_compile(c: RoutingClaim, _ch, cfg: LigeroConfig, base: int):
    ell, T, E = cfg.ELL, c.T, c.E
    L = T * E
    neg1 = (P - 1) % P
    two_l = (1 << c.L_bits) % P
    neg_two_l = (P - two_l) % P
    ones_e = torch.ones(E, dtype=torch.uint64, device="cuda")
    bonus_e = _bonus_vec(E)
    n_rows = (L + ell - 1) // ell

    row_pkts: List[Tuple[int, object]] = []
    cur = base

    # F1: rt − 2^L·r = (E−1−e)
    f1_lo = cur - base
    for ro in range(c.rt.n_rows(ell)):
        row_pkts.append((c.rt.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.rt.row_start, L=L, coef=1)))
    for ro in range(c.r.n_rows(ell)):
        row_pkts.append((c.r.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.r.row_start, L=L, coef=neg_two_l)))
    cur += L
    # F2: Σ_e m[t,e] = 1
    f2_lo = cur - base
    for ro in range(c.m.n_rows(ell)):
        row_pkts.append((c.m.row_start + ro, L2_RowSumPerSlotVector(
            base=cur, var_row_start=c.m.row_start, L=L, stride=E, coef_vec=ones_e)))
    cur += T
    # F3: Σ_e mrt[t,e] − rstar[t] = 0
    for ro in range(c.mrt.n_rows(ell)):
        row_pkts.append((c.mrt.row_start + ro, L2_RowSumPerSlotVector(
            base=cur, var_row_start=c.mrt.row_start, L=L, stride=E, coef_vec=ones_e)))
    for ro in range(c.rstar.n_rows(ell)):
        row_pkts.append((c.rstar.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.rstar.row_start, L=T, coef=neg1)))
    cur += T
    # F4: gap + rt − rstar(broadcast over E) = 0
    for ro in range(c.gap.n_rows(ell)):
        row_pkts.append((c.gap.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.gap.row_start, L=L, coef=1)))
    for ro in range(c.rt.n_rows(ell)):
        row_pkts.append((c.rt.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.rt.row_start, L=L, coef=1)))
    for ro in range(c.rstar.n_rows(ell)):
        row_pkts.append((c.rstar.row_start + ro, L2_StrideOneToManyScalar(
            base=cur, var_row_start=c.rstar.row_start, L=T, stride=E, coef=neg1)))
    cur += L
    # F5: 2^L·r_chosen + Σ_e (E−1−e)·m[t,e] − rstar = 0
    for ro in range(c.r_chosen.n_rows(ell)):
        row_pkts.append((c.r_chosen.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.r_chosen.row_start, L=T, coef=two_l)))
    for ro in range(c.m.n_rows(ell)):
        row_pkts.append((c.m.row_start + ro, L2_RowSumPerSlotVector(
            base=cur, var_row_start=c.m.row_start, L=L, stride=E, coef_vec=bonus_e)))
    for ro in range(c.rstar.n_rows(ell)):
        row_pkts.append((c.rstar.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.rstar.row_start, L=T, coef=neg1)))
    cur += T

    quads: List[QuadFamily] = []
    # Q1: m·m = m   Q2: m·rt = mrt   (one family each)
    for x_v, y_v, z_v, tag in [(c.m, c.m, c.m, "mm"),
                                (c.m, c.rt, c.mrt, "mrt")]:
        quads.append(QuadFamily(
            name=f"Route.{tag}", x_row=x_v.row_start, y_row=y_v.row_start,
            z_row=z_v.row_start, L=L, ell=ell, a=neg1, b=0))

    n_added = cur - base
    # RHS: F1 carries the cyclic bonus pattern (E−1−e); F2 is all-ones.
    fam = [(f1_lo + f, 1, int(E - 1 - (f % E))) for f in range(L) if (f % E) != E - 1]
    fam.append((f2_lo, T, 1))
    b_chunk = _build_b_chunk(n_added, fam)
    return row_pkts, quads, n_added, b_chunk


COMPILE_FNS[RoutingClaim] = routing_compile
SAMPLE_FNS[RoutingClaim] = routing_sample
AUX_FNS[RoutingClaim] = routing_aux
_cf.COMPUTE_FNS[RoutingClaim] = routing_compute


_BUILD = [0]

# Test-only hook (audit A1 finding 3): {field_name: uint64 tensor} overrides
# applied to DERIVED witness values inside the compute fns, so each binding
# constraint family has a negative test that commits an inconsistent value —
# the derive-from-committed-inputs design would otherwise mask a missing
# constraint. List fields use indexed keys ("m_rep0", "prods1"). Tests must
# clear this dict (try/finally).
TEST_TAMPER = {}


def _apply_tamper(outs, named_vars):
    for name, var in named_vars:
        if name in TEST_TAMPER:
            outs[var] = TEST_TAMPER[name].to("cuda")
    return outs


def route_top1(tape, r, *, T, E, B_logit, word_bits=11):
    """Build the RoutingClaim on router logits `r` (T, E), plus the gap range
    check via word_extract. Returns (m, r_chosen, gap) WitnessTensors.

    The mask is DERIVED inside the engine (argmax of the tiebroken logits) —
    no build-time hint, works identically for committed or lazily-derived r.
    Negative tests override derived values via routing_claim.TEST_TAMPER
    (key "m" for the mask itself).

    `B_logit` bounds |r| (enforced UPSTREAM by the producing matmul's
    output_width rescale — a documented soundness precondition)."""
    from tape import WitnessTensor
    _BUILD[0] += 1
    pfx = f"rt{_BUILD[0]}_"
    L_bits = max(1, math.ceil(math.log2(E)))
    width = B_logit + L_bits
    n_words = max(1, math.ceil(width / word_bits))
    # SOUNDNESS GUARD (audit A1 finding 1): the wrong-mask argument requires
    # that the words CANNOT represent the field rep of a negative gap.
    assert n_words * word_bits >= width, "word decomposition must cover the gap width"
    assert (1 << (n_words * word_bits)) <= P - (1 << width), \
        (f"route_top1: unsound parameterization — {n_words}x{word_bits}-bit words "
         f"can reach the negative-gap field range (width={width}). "
         f"Reduce B_logit or word_bits so that 2^(n_words*word_bits) <= P - 2^width.")

    m = tape._alloc(f"{pfx}m", T * E)
    rt = tape._alloc(f"{pfx}rt", T * E)
    mrt = tape._alloc(f"{pfx}mrt", T * E)
    rstar = tape._alloc(f"{pfx}rstar", T)
    gap = tape._alloc(f"{pfx}gap", T * E)
    r_chosen = tape._alloc(f"{pfx}r_chosen", T)

    claim = RoutingClaim(r=r.var, m=m, rt=rt, mrt=mrt, rstar=rstar,
                         gap=gap, r_chosen=r_chosen, T=T, E=E, L_bits=L_bits)
    outs = tape._process_claim(claim, [r.var])
    tape.claims.append(claim)

    m_wt = WitnessTensor(outs[m] if outs else None, m, (T, E), tape)
    gap_wt = WitnessTensor(outs[gap] if outs else None, gap, (T, E), tape)
    rch_wt = WitnessTensor(outs[r_chosen] if outs else None, r_chosen, (T, 1), tape)

    # gap ∈ [0, 2^width): word-decompose and range-check each word against a
    # shared range table (the §B.3 (8) range check, composed from existing claims).
    table = tape.register_table(f"{pfx}rng", T_data=list(range(1 << word_bits)))
    tape.word_extract(gap_wt, table, B=word_bits, N=n_words)
    return m_wt, rch_wt, gap_wt


# ===========================================================================
# FreivaldsCombineClaim — the §B.4 seam: y[t,:] = Σ_e m[t,e]·X_e[t,:] proven
# by random projection instead of committed per-expert products.
#
# A naive masked sum that commits the E·T·F replicated-mask and product slots is
# fine at few tokens but catastrophic at T=1000 × E=128 (~10^12 slots). Here the verifier
# challenge ρ ∈ F^F (derived from s_op per claim index, like Freivalds matmul)
# collapses each expert stream to a per-token scalar:
#
#   s[e,t]  = Σ_j X_e[t,j]·ρ[j]          (linear, phase 2)         C1  [E·T]
#   m_em    = mᵀ (expert-major copy)      (TransposeO2M pin)        C2  [T·E]
#   ms_em   = m_em ⊙ s_em                 (quadratic)               Q1
#   ms_tm   = ms_emᵀ (token-major copy)   (TransposeO2M pin)        C3  [T·E]
#   yr[t]   = Σ_j y[t,j]·ρ[j]            (linear, phase 2)         C4  [T]
#   Σ_e ms_tm[t,·] − yr[t] = 0           (the seam)                C5  [T]
#
# If y[t,:] ≠ Σ_e m[t,e]·X_e[t,:], the two projections differ for random ρ
# except with probability 1/|F| per token (m and y are committed in phase 1,
# ρ is sampled after — same ordering argument as the matmul Freivalds).
# Witness cost: ~4·T·E + T slots instead of ~2·E·T·F.
# ===========================================================================

@dataclass
class FreivaldsCombineClaim:
    m: Variable                 # one-hot mask (T*E), token-major (phase 1)
    xs: List[Variable]          # E per-expert streams, each (T*F) (phase 1)
    y: Variable                 # combined output (T*F); derived unless y_committed
    m_em: Variable              # m transposed to expert-major (E*T), derived
    s_em: Variable              # s[e,t] = X_e[t,:]·ρ (E*T), phase 2
    ms_em: Variable             # m_em ⊙ s_em (E*T), phase 2
    ms_tm: Variable             # ms transposed token-major (T*E), phase 2
    yr: Variable                # y[t,:]·ρ (T), phase 2
    y_committed: bool
    T: int
    E: int
    F: int


def fcombine_sample(c: FreivaldsCombineClaim, ci, s_op):
    import protocol
    return protocol.op_vec(s_op, ci, "rho", c.F)


def fcombine_compute(c: FreivaldsCombineClaim, live):
    """Atomic path = the fold path run all-at-once (single source of truth;
    the NO_FOLD toggle changes only WHEN absorbs happen, never the math)."""
    st = _fc_init(c, live)
    for v in c.xs:
        t = live[v]
        _fc_absorb(c, st, v, t() if callable(t) else t)
    return _fc_finalize(c, st, live)


def fcombine_aux(c: FreivaldsCombineClaim, witness, ch):
    st = {"_eidx": {v: e for e, v in enumerate(c.xs)}, "s_rows": {}}
    for v in c.xs:
        t = witness[v]
        t = (t if isinstance(t, torch.Tensor)
             else torch.tensor(t, dtype=torch.uint64, device="cuda"))
        _fc_aux_absorb(c, st, v, t, ch)
    return _fc_aux_finalize(c, st, witness, ch)


def fcombine_compile(c: FreivaldsCombineClaim, ch, cfg: LigeroConfig, base: int):
    ell, T, E, F = cfg.ELL, c.T, c.E, c.F
    neg1 = (P - 1) % P
    neg_rho = torch.tensor([(P - int(r) % P) % P for r in ch],
                            dtype=torch.uint64, device="cuda")
    ones_e = torch.ones(E, dtype=torch.uint64, device="cuda")
    row_pkts: List[Tuple[int, object]] = []
    cur = base

    # C1: s_em[e·T+t] − Σ_j ρ[j]·X_e[t,j] = 0   (per-expert cid blocks)
    for ro in range(c.s_em.n_rows(ell)):
        row_pkts.append((c.s_em.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.s_em.row_start, L=E * T, coef=1)))
    for e in range(E):
        for ro in range(c.xs[e].n_rows(ell)):
            row_pkts.append((c.xs[e].row_start + ro, L2_RowSumPerSlotVector(
                base=cur + e * T, var_row_start=c.xs[e].row_start,
                L=T * F, stride=F, coef_vec=neg_rho)))
    cur += E * T
    # C2: m_em[e·T+t] − m[t·E+e] = 0
    for ro in range(c.m_em.n_rows(ell)):
        row_pkts.append((c.m_em.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.m_em.row_start, L=E * T, coef=1)))
    for ro in range(c.m.n_rows(ell)):
        row_pkts.append((c.m.row_start + ro, L2_TransposeO2MScalar(
            base=cur, var_row_start=c.m.row_start, L=T * E,
            rows=T, cols=E, fan=1, coef=neg1)))
    cur += T * E
    # C3: ms_tm[t·E+e] − ms_em[e·T+t] = 0
    for ro in range(c.ms_tm.n_rows(ell)):
        row_pkts.append((c.ms_tm.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.ms_tm.row_start, L=T * E, coef=1)))
    for ro in range(c.ms_em.n_rows(ell)):
        row_pkts.append((c.ms_em.row_start + ro, L2_TransposeO2MScalar(
            base=cur, var_row_start=c.ms_em.row_start, L=E * T,
            rows=E, cols=T, fan=1, coef=neg1)))
    cur += T * E
    # C4: yr[t] − Σ_j ρ[j]·y[t,j] = 0
    for ro in range(c.yr.n_rows(ell)):
        row_pkts.append((c.yr.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.yr.row_start, L=T, coef=1)))
    for ro in range(c.y.n_rows(ell)):
        row_pkts.append((c.y.row_start + ro, L2_RowSumPerSlotVector(
            base=cur, var_row_start=c.y.row_start, L=T * F, stride=F,
            coef_vec=neg_rho)))
    cur += T
    # C5: Σ_e ms_tm[t,·] − yr[t] = 0   (the seam)
    for ro in range(c.ms_tm.n_rows(ell)):
        row_pkts.append((c.ms_tm.row_start + ro, L2_RowSumPerSlotVector(
            base=cur, var_row_start=c.ms_tm.row_start, L=T * E, stride=E,
            coef_vec=ones_e)))
    for ro in range(c.yr.n_rows(ell)):
        row_pkts.append((c.yr.row_start + ro, L2_IdentityScalar(
            base=cur, var_row_start=c.yr.row_start, L=T, coef=neg1)))
    cur += T

    quads: List[QuadFamily] = [QuadFamily(
        name="FComb.ms", x_row=c.m_em.row_start, y_row=c.s_em.row_start,
        z_row=c.ms_em.row_start, L=E * T, ell=ell, a=neg1, b=0)]

    return row_pkts, quads, cur - base, None


COMPILE_FNS[FreivaldsCombineClaim] = fcombine_compile
SAMPLE_FNS[FreivaldsCombineClaim] = fcombine_sample
AUX_FNS[FreivaldsCombineClaim] = fcombine_aux
_cf.COMPUTE_FNS[FreivaldsCombineClaim] = fcombine_compute


def freivalds_combine(tape, m, xs, *, T, E, F, force_y=None):
    """Build y[t,:] = Σ_e m[t,e]·xs[e][t,:] via the Freivalds-projected seam
    (§B.4) — the combine: a random projection ρ∈F^F replaces the E·T·F committed
    products, so witness is ~4·E·T not ~2·E·T·F. `force_y` (flat T*F int list,
    test hook) commits a wrong y; the C4/C5 projection seam must then reject."""
    from tape import WitnessTensor
    _BUILD[0] += 1
    pfx = f"fc{_BUILD[0]}_"
    assert m.var.length == T * E, f"mask length {m.var.length} != T*E"
    assert len(xs) == E, f"{len(xs)} expert streams != E"
    for x in xs:
        assert x.var.length == T * F, f"{x.var.name} length {x.var.length} != T*F"
    m_em = tape._alloc(f"{pfx}m_em", E * T)
    if force_y is not None:
        y_data = torch.tensor(list(force_y), dtype=torch.int64,
                              device="cuda").to(torch.uint64)
        y_wt = tape.commit(f"{pfx}y", y_data, (T, F))
        y_var, y_committed = y_wt.var, True
    else:
        y_var, y_committed = tape._alloc(f"{pfx}y", T * F), False
    s_em = Variable(f"{pfx}s_em", length=E * T, phase=2)
    ms_em = Variable(f"{pfx}ms_em", length=E * T, phase=2)
    ms_tm = Variable(f"{pfx}ms_tm", length=T * E, phase=2)
    yr = Variable(f"{pfx}yr", length=T, phase=2)
    claim = FreivaldsCombineClaim(m=m.var, xs=[x.var for x in xs], y=y_var,
                                   m_em=m_em, s_em=s_em, ms_em=ms_em,
                                   ms_tm=ms_tm, yr=yr, y_committed=y_committed,
                                   T=T, E=E, F=F)
    inputs = [m.var] + [x.var for x in xs] + ([y_var] if y_committed else [])
    outs = tape._process_claim(claim, inputs)
    tape.claims.append(claim)
    if y_committed:
        return y_wt
    return WitnessTensor(outs[y_var] if outs else None, y_var, (T, F), tape)


# ── Fold-consumer registration: absorb expert streams as their matmuls retire
#    (frees each X_e immediately — breaks the E·T·F residency barrier).
#    Values are bit-identical to the atomic path (field ops are exact), which
#    test_fc_fold_golden_roots enforces via Merkle-root equality. ──

def _fc_foldable(c: FreivaldsCombineClaim):
    return list(c.xs)


def _fc_init(c: FreivaldsCombineClaim, live):
    T, E, F = c.T, c.E, c.F
    m = live[c.m]
    m = (m() if callable(m) else m).contiguous().view(torch.int64).view(T, E)
    return {"mi": m, "y_acc": torch.zeros(T * F, dtype=torch.uint64, device="cuda"),
            "s_rows": {}, "_eidx": {v: e for e, v in enumerate(c.xs)}}


def _fc_absorb(c: FreivaldsCombineClaim, st, v, t):
    T, F = c.T, c.F
    e = st["_eidx"][v]
    rep = (st["mi"][:, e].contiguous().view(T, 1).expand(T, F).contiguous()
           .view(torch.uint64).reshape(-1))
    st["y_acc"] = gl_add(st["y_acc"], gl_mul(rep, t.contiguous().view(-1)))


def _fc_aux_absorb(c: FreivaldsCombineClaim, st, v, t, ch):
    from cuda_primitives import gl_matvec
    rho = st.get("_rho")
    if rho is None:
        rho = st["_rho"] = torch.tensor(ch, dtype=torch.uint64, device="cuda")
    st["s_rows"][st["_eidx"][v]] = gl_matvec(t.contiguous().view(c.T, c.F), rho)


def _fc_finalize(c: FreivaldsCombineClaim, st, live):
    m_em = st["mi"].T.contiguous().view(torch.uint64).reshape(-1)
    outs = {c.m_em: m_em}
    if not c.y_committed:
        outs[c.y] = st["y_acc"]
    return _apply_tamper(outs, [("m_em", c.m_em)] +
                          ([] if c.y_committed else [("y", c.y)]))


def _fc_aux_finalize(c: FreivaldsCombineClaim, st, live, ch):
    from cuda_primitives import gl_matvec
    T, E, F = c.T, c.E, c.F
    rho = st.get("_rho")
    if rho is None:
        rho = torch.tensor(ch, dtype=torch.uint64, device="cuda")
    s_em = torch.stack([st["s_rows"][e] for e in range(E)]).reshape(-1)
    m_em = live[c.m_em]
    m_em = (m_em() if callable(m_em) else m_em).contiguous().view(-1)
    ms_em = gl_mul(m_em, s_em)
    ms_tm = (ms_em.view(torch.int64).view(E, T).T.contiguous()
             .view(torch.uint64).reshape(-1))
    y = live[c.y]
    y = (y() if callable(y) else y).contiguous()
    yr = gl_matvec(y.view(T, F), rho)
    outs = {c.s_em: s_em, c.ms_em: ms_em, c.ms_tm: ms_tm, c.yr: yr}
    return _apply_tamper(outs, [("s_em", c.s_em), ("ms_em", c.ms_em),
                                 ("ms_tm", c.ms_tm), ("yr", c.yr)])


_cf.FOLD_FNS[FreivaldsCombineClaim] = dict(
    foldable=_fc_foldable, init=_fc_init, absorb=_fc_absorb,
    finalize=_fc_finalize, aux_absorb=_fc_aux_absorb,
    aux_finalize=_fc_aux_finalize)


# ===========================================================================
# RecordPermutationClaim -- private dynamic multiset equality.
#
# This is the binding seam used by the active-only MoE protocol.  Both record
# arrays are phase-1 data.  Only after their Merkle roots are fixed does the
# verifier sample (beta_0..beta_3, alpha).  Phase 2 contains the compressed
# records and reciprocal witnesses.  Thus the prover cannot choose the sorted
# records after seeing the compression/pole challenges.
#
# For record columns r=(r0,r1,r2,r3), let
#       u(r) = sum_i beta_i r_i.
# We prove slotwise u_src/u_dst bindings, inverse identities
#       (alpha-u)*z = 1,
# and the single rational identity sum(z_src)=sum(z_dst).  If the compressed
# multisets differ, the numerator is a non-zero polynomial in alpha of degree
# < 2L; compression collisions add the usual Schwartz-Zippel term in beta.
# The phase ordering is load-bearing; do not move any `src_*`/`dst_*` field to
# phase 2.
# ===========================================================================

@dataclass
class RecordPermutationClaim:
    src_0: Variable
    src_1: Variable
    src_2: Variable
    src_3: Variable
    dst_0: Variable
    dst_1: Variable
    dst_2: Variable
    dst_3: Variable
    u_src: Variable
    u_dst: Variable
    z_src: Variable
    z_dst: Variable
    length: int

    def __post_init__(self):
        raw = (self.src_0, self.src_1, self.src_2, self.src_3,
               self.dst_0, self.dst_1, self.dst_2, self.dst_3)
        aux = (self.u_src, self.u_dst, self.z_src, self.z_dst)
        if self.length <= 0:
            raise ValueError("record permutation must be non-empty")
        if any(v.length != self.length for v in raw + aux):
            raise ValueError("record permutation columns must have equal lengths")
        # Soundness requires the complete source and destination records to be
        # fixed before beta/alpha.  Keep this invariant on the claim itself, not
        # only in the convenience builder, so a future direct constructor cannot
        # silently move a raw column into the challenge-dependent block.
        if any(v.phase != 1 for v in raw):
            raise ValueError("record permutation raw columns must be phase 1")
        if any(v.phase != 2 for v in aux):
            raise ValueError("record permutation reciprocal columns must be phase 2")


def record_permutation_sample(c: RecordPermutationClaim, ci, s_op):
    import protocol
    return (protocol.op_vec(s_op, ci, "perm_beta", 4),
            protocol.op_vec(s_op, ci, "perm_alpha", 1)[0])


def record_permutation_aux(c: RecordPermutationClaim, witness, ch):
    beta, alpha = ch

    def _flat(v):
        x = witness[v]
        if callable(x):
            x = x()
        if not isinstance(x, torch.Tensor):
            x = torch.tensor(x, dtype=torch.uint64, device="cuda")
        return x.contiguous().view(-1)

    def _compress(cols):
        out = torch.zeros(c.length, dtype=torch.uint64, device="cuda")
        for b, v in zip(beta, cols):
            out = gl_add(out, gl_mul(_flat(v), torch.full(
                (c.length,), int(b), dtype=torch.uint64, device="cuda")))
        return out

    us = _compress((c.src_0, c.src_1, c.src_2, c.src_3))
    ud = _compress((c.dst_0, c.dst_1, c.dst_2, c.dst_3))
    aa = torch.full((c.length,), int(alpha), dtype=torch.uint64, device="cuda")
    zs = gl_inv_batched(gl_sub(aa, us))
    zd = gl_inv_batched(gl_sub(aa, ud))
    return {c.u_src: us, c.u_dst: ud, c.z_src: zs, c.z_dst: zd}


def record_permutation_compute(c: RecordPermutationClaim, live):
    # All raw columns are explicit phase-1 inputs.  The challenge-dependent
    # compressed/inverse columns are produced by AUX_FNS in phase 2.
    return {}


def record_permutation_compile(c: RecordPermutationClaim, ch,
                               cfg: LigeroConfig, base: int):
    beta, alpha = ch
    ell, L = cfg.ELL, c.length
    neg = [(P - int(x) % P) % P for x in beta]
    rows: List[Tuple[int, object]] = []

    # u - sum beta_i * record_i = 0, once for each side.
    for u, cols, off in (
            (c.u_src, (c.src_0, c.src_1, c.src_2, c.src_3), 0),
            (c.u_dst, (c.dst_0, c.dst_1, c.dst_2, c.dst_3), L)):
        for ro in range(u.n_rows(ell)):
            rows.append((u.row_start + ro, L2_IdentityScalar(
                base=base + off, var_row_start=u.row_start, L=L, coef=1)))
        for col, co in zip(cols, neg):
            for ro in range(col.n_rows(ell)):
                rows.append((col.row_start + ro, L2_IdentityScalar(
                    base=base + off, var_row_start=col.row_start, L=L, coef=co)))

    # One global reciprocal-sum identity.  Keeping it in the ordinary q_lin
    # family means it is committed before the column challenge exactly like all
    # other Ligero linear tests.
    sum_base = base + 2 * L
    for z, co in ((c.z_src, 1), (c.z_dst, P - 1)):
        for ro in range(z.n_rows(ell)):
            rows.append((z.row_start + ro, L2_StrideManyToOneScalar(
                base=sum_base, var_row_start=z.row_start, L=L,
                stride=L, coef=co)))

    # (alpha-u)z=1  <=>  u*z + (P-alpha)z = P-1.
    quads = [
        QuadFamily("Perm.src.inv", c.u_src.row_start, c.z_src.row_start,
                   c.z_src.row_start, L, ell, (P - int(alpha)) % P, P - 1),
        QuadFamily("Perm.dst.inv", c.u_dst.row_start, c.z_dst.row_start,
                   c.z_dst.row_start, L, ell, (P - int(alpha)) % P, P - 1),
    ]
    return rows, quads, 2 * L + 1, None


COMPILE_FNS[RecordPermutationClaim] = record_permutation_compile
SAMPLE_FNS[RecordPermutationClaim] = record_permutation_sample
AUX_FNS[RecordPermutationClaim] = record_permutation_aux
_cf.COMPUTE_FNS[RecordPermutationClaim] = record_permutation_compute


def record_permutation(tape, src, dst):
    """Append a private 4-column multiset-equality claim.

    `src` and `dst` are four equally-sized committed WitnessTensors.  The
    helper intentionally accepts no raw Python arrays: every record component
    must already be in the phase-1 witness before the challenge epoch.
    """
    assert len(src) == len(dst) == 4
    L = src[0].var.length
    assert all(x.var.length == L for x in tuple(src) + tuple(dst))
    pfx = f"perm{_BUILD[0]}_"
    _BUILD[0] += 1
    us = Variable(f"{pfx}u_src", L, phase=2)
    ud = Variable(f"{pfx}u_dst", L, phase=2)
    zs = Variable(f"{pfx}z_src", L, phase=2)
    zd = Variable(f"{pfx}z_dst", L, phase=2)
    c = RecordPermutationClaim(
        *(x.var for x in src), *(x.var for x in dst), us, ud, zs, zd, L)
    tape._process_claim(c, [x.var for x in tuple(src) + tuple(dst)])
    tape.claims.append(c)
    return c


@dataclass
class LateRecordPermutationClaim:
    """The same multiset argument one commitment epoch later.

    Its raw records are phase 2 (they depend on s_op); beta/alpha come from
    s_bind only after R_p2; compressed/inverse witnesses are phase 3.  This is
    used for contribution and delimiter-emission links in the routed scan.
    """
    src_0: Variable; src_1: Variable; src_2: Variable; src_3: Variable
    dst_0: Variable; dst_1: Variable; dst_2: Variable; dst_3: Variable
    u_src: Variable; u_dst: Variable; z_src: Variable; z_dst: Variable
    length: int

    def __post_init__(self):
        raw = (self.src_0, self.src_1, self.src_2, self.src_3,
               self.dst_0, self.dst_1, self.dst_2, self.dst_3)
        aux = (self.u_src, self.u_dst, self.z_src, self.z_dst)
        if self.length <= 0 or any(v.length != self.length for v in raw + aux):
            raise ValueError("late record permutation columns must be non-empty and equal")
        if any(v.phase != 2 for v in raw):
            raise ValueError("late record permutation raw columns must be phase 2")
        if any(v.phase != 3 for v in aux):
            raise ValueError("late record permutation reciprocal columns must be phase 3")


def late_record_permutation_sample(c, ci, s_op):
    return None


def late_record_permutation_bind_sample(c, ci, s_bind):
    import protocol
    return (protocol.op_vec(s_bind, ci, "late_perm_beta", 4),
            protocol.op_vec(s_bind, ci, "late_perm_alpha", 1)[0])


def late_record_permutation_aux(c, witness, ch):
    return {}


def late_record_permutation_aux3(c, witness, op_ch, bind_ch):
    return record_permutation_aux(c, witness, bind_ch)


def late_record_permutation_compile(c, ch, cfg, base):
    return [], [], 0, None


def late_record_permutation_bind_compile(c, op_ch, bind_ch, cfg, base):
    return record_permutation_compile(c, bind_ch, cfg, base)


SAMPLE_FNS[LateRecordPermutationClaim] = late_record_permutation_sample
AUX_FNS[LateRecordPermutationClaim] = late_record_permutation_aux
COMPILE_FNS[LateRecordPermutationClaim] = late_record_permutation_compile
BIND_SAMPLE_FNS[LateRecordPermutationClaim] = late_record_permutation_bind_sample
AUX3_FNS[LateRecordPermutationClaim] = late_record_permutation_aux3
BIND_COMPILE_FNS[LateRecordPermutationClaim] = late_record_permutation_bind_compile
_cf.COMPUTE_FNS[LateRecordPermutationClaim] = record_permutation_compute


# ===========================================================================
# RoutedProjectedFinalizeClaim -- terminal contraction for an active-only MoE
# matmul after the private segmented scan has produced A[e,k].
#
#   P[e,k] = sum_j rho[j] W[e,k,j]
#   b      = sum_t,j tau[t] rho[j] Y[t,j]
#   Z[e,k] = A[e,k] P[e,k]
#   sum_e,k Z[e,k] = b
#
# A false output matrix is rejected by the two-sided random contraction except
# with probability <= 2/|F|.  P/A/Z/b are phase-2 Ligero rows, never clear
# proof fields.  The scan/permutation claim is responsible for binding A to
# the routed input; this claim binds the remaining weight/output seam.
# ===========================================================================

@dataclass
class RoutedProjectedFinalizeClaim:
    A: Variable                 # (E*K), produced by the private segmented scan
    W: Variable                 # (E*K*J), persistent, layout [e,k,j]
    Y: Variable                 # (T*J), committed output
    P_proj: Variable            # (E*K), phase 2
    Z: Variable                 # (E*K), phase 2
    b: Variable                 # scalar, phase 2
    T: int
    E: int
    K: int
    J: int

    def __post_init__(self):
        if min(self.T, self.E, self.K, self.J) <= 0:
            raise ValueError("routed projected dimensions must be positive")
        if self.A.length != self.E * self.K or self.P_proj.length != self.E * self.K \
                or self.Z.length != self.E * self.K:
            raise ValueError("A/P/Z must have E*K slots")
        if self.W.length != self.E * self.K * self.J:
            raise ValueError("W must have E*K*J slots in [e,k,j] layout")
        if self.Y.length != self.T * self.J or self.b.length != 1:
            raise ValueError("Y/b shape mismatch")
        if self.W.phase != 1 or self.Y.phase != 1:
            raise ValueError("W and Y must be committed before rho/tau")
        if any(v.phase != 2 for v in (self.A, self.P_proj, self.Z, self.b)):
            raise ValueError("A/P/Z/b must be phase-2 rows")


def routed_projected_finalize_sample(c, ci, s_op):
    import protocol
    return (protocol.op_vec(s_op, ci, "rho", c.J),
            protocol.op_vec(s_op, ci, "lam", c.T))


def routed_projected_finalize_compute(c, live):
    return {}


def routed_projected_finalize_aux(c, witness, ch):
    from cuda_primitives import gl_matvec
    rho, lam = ch

    def _flat(v):
        x = witness[v]
        if callable(x): x = x()
        if not isinstance(x, torch.Tensor):
            x = torch.tensor(x, dtype=torch.uint64, device="cuda")
        return x.contiguous().view(-1)

    rho_t = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    lam_t = torch.tensor(lam, dtype=torch.uint64, device="cuda")
    p = gl_matvec(_flat(c.W).view(c.E * c.K, c.J), rho_t)
    a = _flat(c.A)
    z = gl_mul(a, p)
    yr = gl_matvec(_flat(c.Y).view(c.T, c.J), rho_t)
    b = gl_matvec(yr.view(1, c.T), lam_t).reshape(-1)
    return {c.P_proj: p, c.Z: z, c.b: b}


def routed_projected_finalize_compile(c, ch, cfg: LigeroConfig, base: int):
    rho, lam = ch
    ell = cfg.ELL
    EK = c.E * c.K
    neg1 = P - 1
    neg_rho = torch.tensor([(P - int(x) % P) % P for x in rho],
                           dtype=torch.uint64, device="cuda")
    rho_t = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    lam_t = torch.tensor(lam, dtype=torch.uint64, device="cuda")
    rows: List[Tuple[int, object]] = []

    # P[e,k] - sum_j rho[j] W[e,k,j] = 0.
    for ro in range(c.P_proj.n_rows(ell)):
        rows.append((c.P_proj.row_start + ro, L2_IdentityScalar(
            base=base, var_row_start=c.P_proj.row_start, L=EK, coef=1)))
    for ro in range(c.W.n_rows(ell)):
        rows.append((c.W.row_start + ro, L2_FreivaldsLF1B(
            base=base, B_row_start=c.W.row_start, k=EK, n=c.J,
            H=1, K=EK, transpose_b=False, neg_rho=neg_rho)))

    # b - tau^T Y rho = 0.
    bbase = base + EK
    rows.append((c.b.row_start, L2_IdentityScalar(
        base=bbase, var_row_start=c.b.row_start, L=1, coef=1)))
    for ro in range(c.Y.n_rows(ell)):
        rows.append((c.Y.row_start + ro, L2_FreivaldsLF3C(
            base=bbase, C_row_start=c.Y.row_start, m=c.T, n=c.J,
            H=1, L=c.T * c.J, lam=lam_t, rho=rho_t)))

    # sum Z - b = 0.
    sbase = bbase + 1
    for ro in range(c.Z.n_rows(ell)):
        rows.append((c.Z.row_start + ro, L2_StrideManyToOneScalar(
            base=sbase, var_row_start=c.Z.row_start, L=EK,
            stride=EK, coef=1)))
    rows.append((c.b.row_start, L2_IdentityScalar(
        base=sbase, var_row_start=c.b.row_start, L=1, coef=neg1)))

    quads = [QuadFamily("RoutedProjected.AxP", c.A.row_start,
                        c.P_proj.row_start, c.Z.row_start,
                        EK, ell, neg1, 0)]
    return rows, quads, EK + 2, None


COMPILE_FNS[RoutedProjectedFinalizeClaim] = routed_projected_finalize_compile
SAMPLE_FNS[RoutedProjectedFinalizeClaim] = routed_projected_finalize_sample
AUX_FNS[RoutedProjectedFinalizeClaim] = routed_projected_finalize_aux
_cf.COMPUTE_FNS[RoutedProjectedFinalizeClaim] = routed_projected_finalize_compute


def routed_projected_finalize(tape, A, W, Y, *, T, E, K, J):
    """Append the terminal contraction after a preceding phase-2 scan claim."""
    if not tape.lazy:
        raise ValueError("routed_projected_finalize requires the lazy staged engine")
    av = A.var if hasattr(A, "var") else A
    wv = W.var if hasattr(W, "var") else W
    yv = Y.var if hasattr(Y, "var") else Y
    pfx = f"rpf{_BUILD[0]}_"; _BUILD[0] += 1
    pp = Variable(f"{pfx}P", E * K, phase=2)
    zz = Variable(f"{pfx}Z", E * K, phase=2)
    bb = Variable(f"{pfx}b", 1, phase=2)
    c = RoutedProjectedFinalizeClaim(av, wv, yv, pp, zz, bb, T, E, K, J)
    tape._process_claim(c, [av, wv, yv])
    tape.claims.append(c)
    return c


# ===========================================================================
# RoutedProjectedMatmulClaim -- active-only expert matmul without sort/lookup.
#
# R1 fixes M,X,Y and references W.  s_op samples rho over output columns.
# R2 fixes:
#   P[e,k] = sum_j W[e,k,j] rho[j]
#   Q[t,k] = sum_e M[t,e] P[e,k]
#   H[t,k] = X[t,k] Q[t,k]
#   yr[t]  = sum_j Y[t,j] rho[j]
# and checks sum_k H[t,k]=yr[t].  Since P is challenge-dependent, Q=M@P is
# verified only after R2: s_bind samples sigma over K and lambda over T; R3
# commits the ordinary Freivalds auxiliaries for that matrix product.
# ===========================================================================

@dataclass
class RoutedProjectedMatmulClaim:
    M: Variable; X: Variable; Ws: List[Variable]; Y: Variable
    P_proj: Variable; Q: Variable; Hprod: Variable; yr: Variable
    fv_y: Variable; fv_u: Variable; fv_p: Variable
    T: int; E: int; K: int; J: int

    def __post_init__(self):
        expected = ((self.M, self.T * self.E), (self.X, self.T * self.K),
                    (self.Y, self.T * self.J),
                    (self.P_proj, self.E * self.K), (self.Q, self.T * self.K),
                    (self.Hprod, self.T * self.K), (self.yr, self.T),
                    (self.fv_y, self.E), (self.fv_u, self.E), (self.fv_p, self.E))
        if min(self.T, self.E, self.K, self.J) <= 0 or any(v.length != n for v, n in expected):
            raise ValueError("RoutedProjectedMatmulClaim shape mismatch")
        if len(self.Ws) != self.E or any(w.length != self.K*self.J for w in self.Ws):
            raise ValueError("Ws must contain E matrices of K*J slots")
        if any(v.phase != 1 for v in (self.M, self.X, self.Y, *self.Ws)):
            raise ValueError("M/X/Ws/Y must be fixed in R1")
        if any(v.phase != 2 for v in (self.P_proj, self.Q, self.Hprod, self.yr)):
            raise ValueError("P/Q/H/yr must be fixed in R2")
        if any(v.phase != 3 for v in (self.fv_y, self.fv_u, self.fv_p)):
            raise ValueError("late Freivalds auxiliaries must be fixed in R3")


def rpm_sample(c, ci, s_op):
    import protocol
    return protocol.op_vec(s_op, ci, "rho", c.J)


def rpm_bind_sample(c, ci, s_bind):
    import protocol
    return (protocol.op_vec(s_bind, ci, "sigma", c.K),
            protocol.op_vec(s_bind, ci, "lam", c.T))


def rpm_compute(c, live):
    # The production path is a FoldRunner consumer so E lazy weight shards are
    # loaded one at a time.  Keeping this no-op makes accidental non-fold
    # dispatch fail later on the missing Y rather than silently materializing
    # all expert matrices.
    return {}


def _rpm_flat(witness, v):
    x = witness[v]
    if callable(x): x = x()
    if not isinstance(x, torch.Tensor):
        x = torch.tensor(x, dtype=torch.uint64, device="cuda")
    return x.contiguous().view(-1)


def rpm_aux(c, witness, rho):
    rt = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    Pp = torch.stack([
        gl_matvec(_rpm_flat(witness, w).view(c.K, c.J), rt) for w in c.Ws
    ]).view(c.E, c.K)
    # Honest witness uses one-hot gather; the late Freivalds proof, not this
    # computation, is what makes a malicious Q impossible.
    M = _rpm_flat(witness, c.M).view(torch.int64).view(c.T, c.E)
    idx = M.argmax(dim=1)
    Q = Pp.index_select(0, idx).reshape(-1)
    X = _rpm_flat(witness, c.X)
    H = gl_mul(X, Q)
    yr = gl_matvec(_rpm_flat(witness, c.Y).view(c.T, c.J), rt)
    return {c.P_proj: Pp.reshape(-1), c.Q: Q, c.Hprod: H, c.yr: yr}


def rpm_aux3(c, witness, rho, bind_ch):
    sigma, lam = bind_ch
    st = torch.tensor(sigma, dtype=torch.uint64, device="cuda")
    lt = torch.tensor(lam, dtype=torch.uint64, device="cuda")
    Pp = _rpm_flat(witness, c.P_proj).view(c.E, c.K)
    M = _rpm_flat(witness, c.M).view(c.T, c.E)
    fy = gl_matvec(Pp, st)
    fu = gl_matvec(M.T.contiguous(), lt)
    fp = gl_mul(fu, fy)
    return {c.fv_y: fy, c.fv_u: fu, c.fv_p: fp}


def rpm_compile(c, rho, cfg, base):
    ell = cfg.ELL; EK = c.E * c.K; TK = c.T * c.K; neg1 = P - 1
    neg_rho = torch.tensor([(P - int(x) % P) % P for x in rho],
                           dtype=torch.uint64, device="cuda")
    rho_t = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    rows: List[Tuple[int, object]] = []
    # P - W rho = 0.
    for ro in range(c.P_proj.n_rows(ell)):
        rows.append((c.P_proj.row_start + ro, L2_IdentityScalar(
            base=base, var_row_start=c.P_proj.row_start, L=EK, coef=1)))
    for e, w in enumerate(c.Ws):
        for ro in range(w.n_rows(ell)):
            rows.append((w.row_start + ro, L2_FreivaldsLF1B(
                base=base + e*c.K, B_row_start=w.row_start, k=c.K, n=c.J,
                H=1, K=c.K, transpose_b=False, neg_rho=neg_rho)))
    # yr - Y rho = 0.
    ybase = base + EK
    for ro in range(c.yr.n_rows(ell)):
        rows.append((c.yr.row_start + ro, L2_IdentityScalar(
            base=ybase, var_row_start=c.yr.row_start, L=c.T, coef=1)))
    for ro in range(c.Y.n_rows(ell)):
        rows.append((c.Y.row_start + ro, L2_RowSumPerSlotVector(
            base=ybase, var_row_start=c.Y.row_start, L=c.T*c.J,
            stride=c.J, coef_vec=neg_rho)))
    # sum_k H[t,k] - yr[t] = 0.
    sbase = ybase + c.T
    ones = torch.ones(c.K, dtype=torch.uint64, device="cuda")
    for ro in range(c.Hprod.n_rows(ell)):
        rows.append((c.Hprod.row_start + ro, L2_RowSumPerSlotVector(
            base=sbase, var_row_start=c.Hprod.row_start, L=TK,
            stride=c.K, coef_vec=ones)))
    for ro in range(c.yr.n_rows(ell)):
        rows.append((c.yr.row_start + ro, L2_IdentityScalar(
            base=sbase, var_row_start=c.yr.row_start, L=c.T, coef=neg1)))
    quads = [QuadFamily("RPM.XQ", c.X.row_start, c.Q.row_start,
                        c.Hprod.row_start, TK, ell, neg1, 0)]
    return rows, quads, EK + 2*c.T, None


def rpm_bind_compile(c, rho, bind_ch, cfg, base):
    sigma, lam = bind_ch
    ell = cfg.ELL; neg1 = P - 1
    neg_sigma = torch.tensor([(P-int(x)%P)%P for x in sigma],
                             dtype=torch.uint64, device="cuda")
    neg_lam = torch.tensor([(P-int(x)%P)%P for x in lam],
                           dtype=torch.uint64, device="cuda")
    sigma_t = torch.tensor(sigma, dtype=torch.uint64, device="cuda")
    lam_t = torch.tensor(lam, dtype=torch.uint64, device="cuda")
    rows: List[Tuple[int, object]] = []
    # fv_y[e] - sum_k P[e,k] sigma[k] = 0.
    for ro in range(c.fv_y.n_rows(ell)):
        rows.append((c.fv_y.row_start+ro, L2_IdentityScalar(
            base=base, var_row_start=c.fv_y.row_start, L=c.E, coef=1)))
    for ro in range(c.P_proj.n_rows(ell)):
        rows.append((c.P_proj.row_start+ro, L2_RowSumPerSlotVector(
            base=base, var_row_start=c.P_proj.row_start, L=c.E*c.K,
            stride=c.K, coef_vec=neg_sigma)))
    # fv_u[e] - sum_t lambda[t] M[t,e] = 0 (M transpose layout).
    ubase = base + c.E
    for ro in range(c.fv_u.n_rows(ell)):
        rows.append((c.fv_u.row_start+ro, L2_IdentityScalar(
            base=ubase, var_row_start=c.fv_u.row_start, L=c.E, coef=1)))
    for ro in range(c.M.n_rows(ell)):
        rows.append((c.M.row_start+ro, L2_FreivaldsLF2A(
            base=ubase, A_row_start=c.M.row_start, k=c.E, m=c.T,
            H=1, K=c.E, neg_lam=neg_lam)))
    # sum_e fv_p[e] - lambda^T Q sigma = 0.
    fbase = ubase + c.E
    for ro in range(c.fv_p.n_rows(ell)):
        rows.append((c.fv_p.row_start+ro, L2_StrideManyToOneScalar(
            base=fbase, var_row_start=c.fv_p.row_start, L=c.E,
            stride=c.E, coef=1)))
    for ro in range(c.Q.n_rows(ell)):
        rows.append((c.Q.row_start+ro, L2_FreivaldsLF3C(
            base=fbase, C_row_start=c.Q.row_start, m=c.T, n=c.K,
            H=1, L=c.T*c.K, lam=lam_t, rho=sigma_t)))
    quads = [QuadFamily("RPM.FV", c.fv_u.row_start, c.fv_y.row_start,
                        c.fv_p.row_start, c.E, ell, neg1, 0)]
    return rows, quads, 2*c.E + 1, None


SAMPLE_FNS[RoutedProjectedMatmulClaim] = rpm_sample
AUX_FNS[RoutedProjectedMatmulClaim] = rpm_aux
COMPILE_FNS[RoutedProjectedMatmulClaim] = rpm_compile
BIND_SAMPLE_FNS[RoutedProjectedMatmulClaim] = rpm_bind_sample
AUX3_FNS[RoutedProjectedMatmulClaim] = rpm_aux3
BIND_COMPILE_FNS[RoutedProjectedMatmulClaim] = rpm_bind_compile
_cf.COMPUTE_FNS[RoutedProjectedMatmulClaim] = rpm_compute


def _rpm_fold_init(c, live):
    M = _rpm_flat(live, c.M).view(c.T, c.E)
    X = _rpm_flat(live, c.X).view(c.T, c.K)
    route = M.view(torch.int64).argmax(dim=1)
    return {
        "M": M, "X": X, "route": route,
        "Y": torch.zeros((c.T, c.J), dtype=torch.uint64, device="cuda"),
        "P": [None] * c.E,
    }


def _rpm_fold_absorb(c, st, var, tensor):
    """Compute only rows whose committed route selects this weight shard."""
    e = c.Ws.index(var)
    sel = torch.nonzero(st["route"] == e, as_tuple=False).reshape(-1)
    if sel.numel() == 0:
        return
    x_e = st["X"].index_select(0, sel).contiguous()
    w_e = tensor.contiguous().view(c.K, c.J)
    y_e = gl_matmul(x_e, w_e)
    # index_copy_ is a true scatter into the sole active output.  No E*T*J
    # expert-output tensor is ever allocated.
    st["Y"].index_copy_(0, sel, y_e)


def _rpm_fold_aux_absorb(c, st, var, tensor, rho):
    rho_key = tuple(int(x) for x in rho)
    if getattr(c, "_projection_rho", None) == rho_key:
        return
    e = c.Ws.index(var)
    rho_key = tuple(int(x) for x in rho)
    if st.get("rho_key") != rho_key:
        st["rho_key"] = rho_key
        st["rho_t"] = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    rt = st["rho_t"]
    st["P"][e] = gl_matvec(tensor.contiguous().view(c.K, c.J), rt)


def _rpm_fold_finalize(c, st, live):
    return {c.Y: st["Y"].reshape(-1)}


def _rpm_fold_aux_finalize(c, st, live, rho):
    rho_key = tuple(int(x) for x in rho)
    if getattr(c, "_projection_rho", None) == rho_key:
        Pp = c._projection_cache
    else:
        if any(x is None for x in st["P"]):
            raise RuntimeError("RPM projection did not consume every expert shard")
        Pp = torch.stack(st["P"]).view(c.E, c.K)
        # P is the sole 400B-scan result.  Across all 72 expert matmuls it is
        # only 56.6M fields (~453 MB), so retaining it removes three duplicate
        # challenge-identical weight projections without retaining the trace.
        c._projection_rho = rho_key
        c._projection_cache = Pp
    Q = Pp.index_select(0, st["route"]).reshape(-1)
    H = gl_mul(st["X"].reshape(-1), Q)
    rt = st.get("rho_t")
    if rt is None:
        rt = torch.tensor(rho, dtype=torch.uint64, device="cuda")
    yr = gl_matvec(st["Y"], rt)
    return {c.P_proj: Pp.reshape(-1), c.Q: Q, c.Hprod: H, c.yr: yr}


_cf.FOLD_FNS[RoutedProjectedMatmulClaim] = dict(
    foldable=lambda c: c.Ws,
    init=_rpm_fold_init,
    absorb=_rpm_fold_absorb,
    finalize=_rpm_fold_finalize,
    aux_absorb=_rpm_fold_aux_absorb,
    aux_finalize=_rpm_fold_aux_finalize,
)


def routed_projected_matmul(tape, M, X, Ws, *, T, E, K, J, name=None):
    """Compute and prove one active-only expert matmul.

    Expert weights are consumed shard-by-shard.  The phase-1 output contains
    exactly T*J raw accumulator slots; phase 2 contains the output projection
    and active gathered projection, never E independent output streams.
    """
    if not tape.lazy:
        raise ValueError("routed_projected_matmul requires the lazy staged engine")
    mv = M.var if hasattr(M, "var") else M
    xv = X.var if hasattr(X, "var") else X
    wvs = [w.var if hasattr(w, "var") else w for w in Ws]
    pfx = f"rpm{_BUILD[0]}_"; _BUILD[0] += 1
    yv = tape._alloc(name or f"{pfx}Y", T*J)
    pp = Variable(f"{pfx}P", E*K, phase=2)
    qq = Variable(f"{pfx}Q", T*K, phase=2)
    hh = Variable(f"{pfx}H", T*K, phase=2)
    yr = Variable(f"{pfx}yr", T, phase=2)
    fy = Variable(f"{pfx}fy", E, phase=3)
    fu = Variable(f"{pfx}fu", E, phase=3)
    fp = Variable(f"{pfx}fp", E, phase=3)
    c = RoutedProjectedMatmulClaim(
        mv, xv, wvs, yv, pp, qq, hh, yr, fy, fu, fp, T, E, K, J)
    tape._process_claim(c, [mv, xv, *wvs])
    tape.claims.append(c)
    from tape import WitnessTensor
    return WitnessTensor(None, yv, (T, J), tape)
