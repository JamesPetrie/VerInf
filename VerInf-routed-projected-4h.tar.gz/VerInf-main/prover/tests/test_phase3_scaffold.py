"""Structural gates for the optional fifth-message / phase-3 scaffold.

These tests deliberately avoid CUDA: they pin the transcript-independent
layout and challenge dispatch which existing phase-1/2 claims rely on.
"""
from dataclasses import dataclass

from core import (
    BIND_SAMPLE_FNS, LigeroConfig, Proof, Variable,
    _claim_var_groups, _layout, _sample_bind_chs,
)
from protocol import _ser_var


@dataclass
class _ThreePhaseClaim:
    raw: Variable
    compressed: Variable
    linked: Variable


def _fixture():
    claim = _ThreePhaseClaim(
        Variable("raw", 9, phase=1),
        Variable("compressed", 7, phase=2),
        Variable("linked", 5, phase=3),
    )
    return claim, LigeroConfig(ELL=4, K_DEG=8, N_LIG=16, T_QUERIES=2)


def test_phase3_layout_and_grouping():
    claim, cfg = _fixture()
    (all_vars, p1, p2, p3, p2_start, p3_start, total,
     weights, m_w, wnew, m_wnew) = _layout([claim], cfg, include_phase3=True)
    assert all_vars == [claim.raw, claim.compressed, claim.linked]
    assert (p1, p2, p3) == ([claim.raw], [claim.compressed], [claim.linked])
    assert claim.raw.row_start < p2_start == claim.compressed.row_start
    assert claim.compressed.row_start < p3_start == claim.linked.row_start
    assert total == claim.linked.row_start + claim.linked.n_rows(cfg.ELL)
    assert (weights, m_w, wnew, m_wnew) == ([], 0, [], 0)
    assert _claim_var_groups([claim], cfg) == [(claim, p1, p2, p3)]


def test_legacy_layout_shape_is_unchanged():
    _claim, cfg = _fixture()
    claim = _ThreePhaseClaim(
        Variable("raw-old", 9, phase=1),
        Variable("compressed-old", 7, phase=2),
        Variable("linked-old", 5, phase=2),
    )
    legacy = _layout([claim], cfg)
    assert len(legacy) == 9
    assert legacy[1] == [claim.raw]
    assert legacy[2] == [claim.compressed, claim.linked]


def test_legacy_layout_fails_closed_on_phase3():
    claim, cfg = _fixture()
    try:
        _layout([claim], cfg)
    except ValueError as exc:
        assert "phase-3" in str(exc)
    else:
        raise AssertionError("legacy two-phase layout accepted a phase-3 variable")


def test_bind_sampler_is_opt_in_and_indexed():
    claim, _ = _fixture()
    seed = bytes(range(32))
    BIND_SAMPLE_FNS[_ThreePhaseClaim] = (
        lambda c, ci, s: (c.linked.length, ci, s[-1]))
    try:
        assert _sample_bind_chs([claim], seed) == [(5, 0, 31)]
    finally:
        BIND_SAMPLE_FNS.pop(_ThreePhaseClaim, None)


def test_proof_phase3_defaults_are_backwards_compatible():
    # Avoid constructing tensors: dataclass fields are not type-enforced and
    # this test only pins the optional p3 API surface.
    proof = Proof(b"1" * 32, b"2" * 32, None, None, None, {}, {}, {}, {})
    assert proof.root_p3 is None
    assert proof.opened_p3 == {}
    assert proof.paths_p3 == {}


def test_only_phase3_changes_variable_wire_shape():
    assert _ser_var(Variable("old-p1", 1, phase=1)) == [-1, 1]
    assert _ser_var(Variable("old-p2", 1, phase=2)) == [-1, 1]
    assert _ser_var(Variable("new-p3", 1, phase=3)) == [-1, 1, 3]
