"""Full 48-layer Llama-4-Maverick proof with unexplained-information claim.

Input binding (analysis/full-model-v1-design.md, updated 2026-07-08):
  * ALL positions HIDDEN — committed one-hot indicators, RoutingClaim
    constrains each row one-hot (booleanity + cardinality hold regardless of
    the committed indicator), x = m @ E selects the rows. Token ids never
    appear as numbers; only the unexplained-information bound is public.
  * The indicator rows for positions 1..T-1 are SHARED with the UI output
    select (O = ind_mid ‖ o_last via ConcatClaim), so one committed token
    stream drives both the forward pass and the surprisal: the scored token
    at position t is provably the input token at position t+1.

Layers: even = dense FFN (d_ff 16384), odd = MoE (128 experts + shared,
Freivalds-projected combines); NoPE (no rope) when (il+1) % 4 == 0; attention
temperature tuning is exactly 1 below position 8192 (llama-graph.cpp) — not
modeled. Tail: final RMSNorm·gain → LM head → prove_unexplained_info summed
over the continuation positions.

Modes:
  --witness-only   run_engine_pass(free_intermediates) — no proof; prints the
                   REAL UI number + argmax-vs-continuation agreement and dumps
                   logits for the llama.cpp cross-check. (H100 safety run.)
  default          full streaming prove + streaming dump.   (Spark run.)

Run:
  PATH=~/venv-hf/bin:$PATH LIGERO_T_QUERIES=4 \\
  LIGERO_STREAM_DBG=1 python demo_maverick_full.py \\
      --from-gguf ~/maverick-gguf/UD-Q4_K_XL --tokens ~/inference-1k/tokens.json \\
      --dump-proof /tmp/maverick_full.json
"""
import argparse
import json
import math
import os
import sys
import pathlib
import time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import torch

import sys as _s, pathlib as _pl
_R = _pl.Path(__file__).resolve().parents[1]
_s.path.insert(0, str(_R / "prover")); _s.path.insert(0, str(_R / "demo"))
import _uint64_compat  # noqa: F401

import core
from core import P
import claims as _C          # noqa: F401
import packets as _PK         # noqa: F401
from tape import Tape, WitnessTensor
from routing_claim import route_top1, freivalds_combine, routed_projected_matmul
from unexplained_info import prove_unexplained_info, bound_bits
from demo_maverick_moe import (_to_field, _rand_int, _sigmoid_table, CFG, S,
                                SCALE_BITS, OUTPUT_WIDTH, SILU_CFG, SIG_SHIFT,
                                WORD_BITS, HALF_X)
from demo_maverick_block import (load_attention, build_attn_chain, EPS_INT,
                                  H, HKV, DH)

SEED = b"maverick-full-demo"
# s_y = 2^18 > V: the proven EXP table floors every entry at 1 (soundness:
# LogUp entries nonzero, round-up keeps U an upper bound), so the partition
# carries a log2(V/s_y) floor — 5.62 bits/token at s_y=2^12 (measured: proven
# 5.87 vs float 0.60). At 2^18 the floor is ~0 and proven ~= float.
# s_y >> V (202048) so the LogUp exp-table floor log2(1+V/s_y) ~= 0.001
# bits is negligible (2^18 left ~0.8 bits of floor; 2^28 is clean).
UI = dict(s_c=1 << 28, s_y=1 << 28, s_b=1 << 12, gap_max=1 << 20)


def _log(msg):
    print(f"[maverick-full] {msg}", flush=True)


def _field_loader(gguf, name, S_=S, transpose=False):
    """Closure: GGUF tensor -> field ints, fused kernel when possible."""
    def load():
        from loader import _gguf_by_name, quantize_to_field
        from kquant_cuda import kquant_to_field
        from gguf.quants import dequantize
        import numpy as np
        t = _gguf_by_name(gguf)[name]
        qt = t.tensor_type.name
        if qt in ("Q4_K", "Q5_K", "Q6_K"):
            d_out = int(t.data.shape[0])
            w = kquant_to_field(torch.from_numpy(
                np.ascontiguousarray(t.data)).cuda(), qt, S_).view(d_out, -1)
        else:
            d = dequantize(np.ascontiguousarray(t.data), t.tensor_type)
            w = quantize_to_field(torch.from_numpy(d.copy()), S_).view(d.shape[0], -1)
        if transpose:
            w = w.view(torch.int64).T.contiguous().view(torch.uint64)
        return w.reshape(-1)
    return load


def build_inputs(tape, gguf, E_wt, prompt_ids, cont_ids, *, V, d):
    """ALL tokens hidden: committed one-hot indicators, never revealed,
    one-hot enforced by claim, x = m @ E. Returns (x, ind_mid, o_last).

    The indicator is committed in two pieces so its rows can be SHARED with
    the unexplained-information output select: `ind_mid` holds positions
    1..T-1, which are simultaneously the input tokens at those positions
    and (shifted by one) the scored output tokens at positions 0..T-2. The
    caller concats (ind_mid, o_last) into the UI's O, so ONE committed
    token stream provably drives both the forward pass and the surprisal."""
    ids = list(prompt_ids) + list(cont_ids)
    T = len(ids)

    def _onehot(rows_ids):
        n = len(rows_ids)
        ind = torch.zeros(n, V, dtype=torch.int64, device="cuda")
        ind[torch.arange(n), torch.tensor(rows_ids)] = 1
        return ind.reshape(-1).to(torch.uint64)

    ind0 = tape.commit("tok_ind0", _onehot(ids[:1]), (1, V))
    ind_mid = tape.commit("tok_ind_mid", _onehot(ids[1:]), (T - 1, V))
    # the UI's last row: targets[T-1] = ids[-1] (a repeat, excluded from the sum)
    o_last = tape.commit("tok_olast", _onehot(ids[-1:]), (1, V))

    r_ind = tape.concat([ind0, ind_mid], (T, V))
    m, _rc, _gap = route_top1(tape, r_ind, T=T, E=V, B_logit=1, word_bits=11)
    # exact select (one-hot row sum, no rescale): scale-free matmul claim
    x = tape.matmul(m, E_wt)
    return x, ind_mid, o_last


def build_dense_ffn(tape, n2g, gguf, il, *, T, d):
    mm = dict(s_a=S, s_b=S, s_out=S, output_width=OUTPUT_WIDTH)
    from loader import _gguf_by_name
    by = _gguf_by_name(gguf)
    d_ff = int(by[f"blk.{il}.ffn_gate.weight"].data.shape[0])
    Wg = tape.commit_lazy(f"L{il}_Wg", _field_loader(gguf, f"blk.{il}.ffn_gate.weight",
                                                      transpose=True), (d, d_ff), d * d_ff)
    Wu = tape.commit_lazy(f"L{il}_Wu", _field_loader(gguf, f"blk.{il}.ffn_up.weight",
                                                      transpose=True), (d, d_ff), d * d_ff)
    Wd = tape.commit_lazy(f"L{il}_Wd", _field_loader(gguf, f"blk.{il}.ffn_down.weight",
                                                      transpose=True), (d_ff, d), d_ff * d)
    g = tape.matmul(n2g, Wg, **mm)
    u = tape.matmul(n2g, Wu, **mm)
    h = tape.hadamard(tape.silu(g), u, **mm)
    return tape.matmul(h, Wd, **mm)


def _moe_parts(gguf, il, E):
    """One decode per sweep/layer for router + shared tensors.

    ``load_maverick_moe_layer`` produces all four values at once.  Giving each
    Variable an independent closure used to repeat that conversion four times.
    Entries are popped as consumed, so the cache cannot retain prior layers.
    """
    cache = {}
    keys = ("W_router", "W_gate_sh", "W_up_sh", "W_down_sh")
    def loader(key):
        def load():
            if not cache:
                from loader import load_maverick_moe_layer
                real = load_maverick_moe_layer(
                    gguf, il, S=S, n_experts=E, skip_experts=True)
                cache.update({k: real[k].contiguous().reshape(-1) for k in keys})
            return cache.pop(key)
        return load
    return {k: loader(k) for k in keys}


def build_moe_ffn(tape, n2g, gguf, il, sig_tbl, ones_bc, *, T, E, d, d_ff):
    """MoE FFN with a single active output stream per expert matmul."""
    from loader import maverick_lazy_expert
    mm = dict(s_a=S, s_b=S, s_out=S, output_width=OUTPUT_WIDTH)

    def wexp(kind, name, shape, e):
        ld = maverick_lazy_expert(gguf, il, kind, e, S)
        return tape.commit_lazy(name, ld, shape, shape[0] * shape[1])

    shared_load = _moe_parts(gguf, il, E)
    W_router = tape.commit_lazy(f"L{il}_Wr", shared_load["W_router"], (d, E), d * E)
    r = tape.matmul(n2g, W_router, **mm)
    m, r_chosen, _g = route_top1(tape, r, T=T, E=E, B_logit=OUTPUT_WIDTH,
                                  word_bits=WORD_BITS)
    s_val = tape.paired_tlookup(r_chosen, sig_tbl, shift=SIG_SHIFT)
    s_rep = freivalds_combine(tape, s_val, [ones_bc], T=T, E=1, F=d)
    x_r = tape.hadamard(s_rep, n2g, **mm)

    W_gate = [wexp("gate_exps", f"L{il}_Wg{e}", (d, d_ff), e) for e in range(E)]
    W_up = [wexp("up_exps", f"L{il}_Wu{e}", (d, d_ff), e) for e in range(E)]
    g_raw = routed_projected_matmul(
        tape, m, x_r, W_gate, T=T, E=E, K=d, J=d_ff, name=f"L{il}_g_raw")
    u_raw = routed_projected_matmul(
        tape, m, x_r, W_up, T=T, E=E, K=d, J=d_ff, name=f"L{il}_u_raw")
    g_sum = tape.rescale(g_raw, rescale_bits=SCALE_BITS,
                         output_width=OUTPUT_WIDTH, name=f"L{il}_g")
    up_sum = tape.rescale(u_raw, rescale_bits=SCALE_BITS,
                          output_width=OUTPUT_WIDTH, name=f"L{il}_u")
    hidden = tape.hadamard(tape.silu(g_sum), up_sum, **mm)
    W_down = [wexp("down_exps", f"L{il}_Wd{e}", (d_ff, d), e) for e in range(E)]
    f_raw = routed_projected_matmul(
        tape, m, hidden, W_down, T=T, E=E, K=d_ff, J=d, name=f"L{il}_f_raw")
    ffn = tape.rescale(f_raw, rescale_bits=SCALE_BITS,
                       output_width=OUTPUT_WIDTH, name=f"L{il}_ffn")

    Wg_s = tape.commit_lazy(f"L{il}_Wgs", shared_load["W_gate_sh"], (d, d_ff), d * d_ff)
    Wu_s = tape.commit_lazy(f"L{il}_Wus", shared_load["W_up_sh"], (d, d_ff), d * d_ff)
    Wd_s = tape.commit_lazy(f"L{il}_Wds", shared_load["W_down_sh"], (d_ff, d), d_ff * d)
    h_s = tape.hadamard(tape.silu(tape.matmul(n2g, Wg_s, **mm)),
                         tape.matmul(n2g, Wu_s, **mm), **mm)
    sh = tape.matmul(h_s, Wd_s, **mm)
    return ffn + sh


def build_model(tape, gguf, prompt_ids, cont_ids, *, V, d, n_layers, E, d_ff):
    from loader import _gguf_by_name
    by = _gguf_by_name(gguf)
    T = len(prompt_ids) + len(cont_ids)
    theta = 500000.0

    E_wt = tape.commit_lazy("token_embd", _field_loader(gguf, "token_embd.weight"),
                             (V, d), V * d)
    x, ind_mid, o_last = build_inputs(tape, gguf, E_wt, prompt_ids, cont_ids, V=V, d=d)
    _log(f"input bound: all {T} tokens hidden ({len(prompt_ids)} prompt + "
         f"{len(cont_ids)} continuation)")

    t_in, t_out = _sigmoid_table()
    sig_tbl = tape.register_table("sigmoid", T_data=t_in, T_Y_data=t_out)
    ones_bc = tape.commit("bc_ones", torch.ones(T * d, dtype=torch.uint64,
                                                 device="cuda"), (T, d))

    for il in range(n_layers):
        attn = {}
        # gains are tiny (d,) — eager; projection weights lazy (1.7 GB/layer
        # eager across 48 layers OOMs the H100's 80 GB VRAM)
        # Gains are eager, but Q/K/V/O share a ref-counted lazy decode cache in
        # each later sweep.  No decoded tensor survives past W_O.
        attn["g_attn_wt"] = tape.commit(
            f"L{il}_gA", _field_loader(gguf, f"blk.{il}.attn_norm.weight")(), (d,))
        attn["g_ffn_wt"] = tape.commit(
            f"L{il}_gF", _field_loader(gguf, f"blk.{il}.ffn_norm.weight")(), (d,))
        attn_cache = {}
        attn_keys = ("W_Q", "W_K", "W_V", "W_O")
        def _attn_part(key, _il=il, _cache=attn_cache):
            def load():
                if not _cache:
                    vals = load_attention(gguf, _il)
                    _cache.update({k: vals[k].reshape(-1) for k in attn_keys})
                return _cache.pop(key)
            return load
        for kk, nm, sh in [("W_Q_wt", "W_Q", (d, H * DH)), ("W_K_wt", "W_K", (d, H * DH)),
                            ("W_V_wt", "W_V", (d, H * DH)), ("W_O_wt", "W_O", (H * DH, d))]:
            attn[kk] = tape.commit_lazy(f"L{il}_{nm}", _attn_part(nm),
                                         sh, sh[0] * sh[1])
        use_rope = (il + 1) % 4 != 0
        resid1, n2g = build_attn_chain(tape, x, attn, T=T, d=d, theta=theta,
                                        use_rope=use_rope)
        if il % 2 == 1:
            ffn = build_moe_ffn(tape, n2g, gguf, il, sig_tbl, ones_bc,
                                 T=T, E=E, d=d, d_ff=d_ff)
            kind = f"moe E={E}"
        else:
            ffn = build_dense_ffn(tape, n2g, gguf, il, T=T, d=d)
            kind = "dense"
        x = resid1 + ffn
        _log(f"layer {il} built ({kind}, rope={use_rope}) — "
             f"{len(tape.claims)} claims so far")

    # final norm + gain -> LM head
    n_f = tape.rmsnorm(x, d=d, s=S, eps_int=EPS_INT, slack_n_chunks=4,
                        s_out=S, output_width=OUTPUT_WIDTH)
    g_out = tape.commit("g_out", _field_loader(gguf, "output_norm.weight")(), (d,))
    n_fg = tape.hadamard_broadcast(n_f, g_out, SEQ=T, d=d, s_a=S, s_b=S,
                                    s_out=S, output_width=OUTPUT_WIDTH)
    lm_name = "output.weight" if "output.weight" in by else "token_embd.weight"
    W_lm = tape.commit_lazy("W_lm", _field_loader(gguf, lm_name, transpose=True),
                             (d, V), d * V)
    logits = tape.matmul(n_fg, W_lm, s_a=S, s_b=S, s_out=S,
                          output_width=OUTPUT_WIDTH)
    _log(f"LM head from {lm_name} ({'tied' if lm_name != 'output.weight' else 'untied'})")

    # UI over the continuation: position t predicts ids[t+1]. The output
    # select O is the INPUT indicator rows shifted by one (ind_mid holds
    # one-hots of ids[1:]), plus a repeat of the last row for position T-1
    # (excluded from the sum) — so the scored tokens are, by shared
    # committed variable, the tokens the model consumed.
    ids = list(prompt_ids) + list(cont_ids)
    targets = ids[1:] + [ids[-1]]
    O_ext = tape.concat([ind_mid, o_last], (T, V))
    sum_pos = list(range(len(prompt_ids) - 1, T - 1))
    Sz, handles = prove_unexplained_info(tape, logits, targets, T=T, V=V,
                                          sum_positions=sum_pos, reveal=True,
                                          O_ext=O_ext, **UI)
    _log(f"UI claim over {len(sum_pos)} continuation positions; "
         f"{len(tape.claims)} claims total")
    return logits, Sz, handles, sum_pos


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from-gguf", required=True)
    ap.add_argument("--tokens", default=None, help="tokens.json (prompt+continuation)")
    ap.add_argument("--layers", type=int, default=48)
    ap.add_argument("--experts", type=int, default=128)
    ap.add_argument("--d", type=int, default=5120)
    ap.add_argument("--d-ff", type=int, default=8192)
    ap.add_argument("--vocab", type=int, default=202048)
    ap.add_argument("--prompt-n", type=int, default=0, help="synthetic prompt len")
    ap.add_argument("--cont-n", type=int, default=0, help="synthetic continuation len")
    ap.add_argument("--witness-only", action="store_true")
    ap.add_argument("--weight-commitment", default=None,
                    help="pre-enrolled persistent WeightCommitment file; required for the 4h path")
    ap.add_argument("--expected-weight-root", default=None,
                    help="trusted 32-byte model root in hex; required with --weight-commitment")
    ap.add_argument("--admission-report", default=None,
                    help="simultaneous p99 production rate-card; required for target proof")
    ap.add_argument("--enroll-weights", default=None,
                    help="build and save the persistent weight commitment, then exit")
    ap.add_argument("--dump-proof", default=None)
    ap.add_argument("--logits-out", default=None)
    ap.add_argument("--ui-abort-above", type=float, default=None,
                    help="bits/token threshold: if the reveal engine pass "
                         "(run before the prove sweep) computes a bound above "
                         "this, abort BEFORE the ~8h sweep instead of proving "
                         "a useless number")
    ap.add_argument("--public-sz", type=int, default=None,
                    help="trusted public Sz from the serving statement; required for the 4h proof path")
    ap.add_argument("--allow-nontarget", action="store_true",
                    help="development only: permit proof dimensions other than the 400B/S=1000 target")
    a = ap.parse_args()
    torch.manual_seed(7)

    if a.tokens:
        tk = json.load(open(a.tokens))
        prompt_ids, cont_ids = tk["prompt"], tk["continuation"]
    else:
        g = torch.Generator().manual_seed(11)
        prompt_ids = torch.randint(0, a.vocab, (a.prompt_n or 4,), generator=g).tolist()
        cont_ids = torch.randint(0, a.vocab, (a.cont_n or 4,), generator=g).tolist()
    T = len(prompt_ids) + len(cont_ids)
    _log(f"layers={a.layers} E={a.experts} T={T} V={a.vocab} "
         f"T_QUERIES={CFG.T_QUERIES} witness_only={a.witness_only}")
    target = (a.layers, a.experts, T, a.d, a.d_ff, a.vocab, CFG.T_QUERIES)
    expected = (48, 128, 1000, 5120, 8192, 202048, 54)
    exact_target = target == expected
    if exact_target and not a.enroll_weights and not a.witness_only:
        if not a.dump_proof:
            raise SystemExit("target proof requires --dump-proof; refusing a run with no artifact")
        dump_parent = os.path.dirname(os.path.abspath(a.dump_proof)) or "."
        if not os.path.isdir(dump_parent):
            raise SystemExit(f"proof output directory does not exist: {dump_parent}")
        sv = os.statvfs(dump_parent)
        free = sv.f_bavail * sv.f_frsize
        if free < 100_000_000_000:
            raise SystemExit(f"target proof requires >=100GB free before start; have {free/1e9:.1f}GB")
    if a.weight_commitment and not exact_target and not a.allow_nontarget:
        raise SystemExit(f"4h production profile is exactly {expected}; got {target}. "
                         "Use --allow-nontarget only for development runs.")

    tape = Tape(CFG, silu_config=SILU_CFG, lazy=True)
    t0 = time.time()
    logits, Sz, handles, sum_pos = build_model(
        tape, a.from_gguf, prompt_ids, cont_ids, V=a.vocab, d=a.d,
        n_layers=a.layers, E=a.experts, d_ff=a.d_ff)
    _log(f"build {time.time()-t0:.1f}s, {len(tape.claims)} claims")

    if a.enroll_weights:
        import secrets
        from core import WeightCommitment
        t0 = time.time()
        wc = WeightCommitment.from_tape(tape, CFG, master_seed=secrets.token_bytes(32))
        wc.save(a.enroll_weights)
        _log(f"persistent weight enrollment {time.time()-t0:.1f}s: "
             f"root={wc.root.hex()} rows={wc.m_w:,} -> {a.enroll_weights}")
        return 0

    if a.witness_only:
        t0 = time.time()
        keep = {logits.var, Sz.var, handles["surprisal"].var}
        live = tape.run_engine_pass(free_intermediates=True, keep=keep)
        _log(f"witness pass {time.time()-t0:.1f}s "
             f"peakGPU={torch.cuda.max_memory_allocated()/2**30:.2f}GB")
        from max_claim import to_signed
        lg = to_signed(live[logits.var].reshape(-1)).view(T, a.vocab)
        ids = list(prompt_ids) + list(cont_ids)
        agree = sum(int(lg[t].argmax().item() == ids[t + 1])
                    for t in range(len(prompt_ids) - 1, T - 1))
        Sz_v = int(live[Sz.var].cpu()[0])
        bits_total = bound_bits(Sz_v, s_b=UI["s_b"])
        _log(f"UI: Sz={Sz_v}  ->  {bits_total:.1f} bits total = "
             f"{bits_total/len(sum_pos):.4f} bits/token over {len(sum_pos)} "
             f"continuation positions")
        _log(f"greedy agreement: {agree}/{len(sum_pos)} continuation argmax matches")
        if a.logits_out:
            import numpy as np
            np.save(a.logits_out, lg.cpu().numpy().astype("int64"))
            _log(f"logits saved to {a.logits_out}")
        return 0

    # Sz is part of the public statement and must be fixed before R1.  Computing
    # it here would add an unmodelled full witness pass and, more importantly,
    # let the prover choose the statement after seeing its private inference.
    if handles.get("reveal_pin") is not None:
        if a.public_sz is None:
            raise SystemExit("production proof requires --public-sz from the trusted serving statement")
        if not (0 <= a.public_sz < P):
            raise SystemExit("--public-sz must be the canonical field representative in [0,P)")
        handles["reveal_pin"].public_rhs = int(a.public_sz)
        _bits = bound_bits(a.public_sz, s_b=UI["s_b"])
        _bpt = _bits / len(sum_pos)
        if a.ui_abort_above is not None and _bpt > a.ui_abort_above:
            raise SystemExit(f"public statement is above policy: {_bpt:.4f} bits/token")
        _log(f"statement: Sz={a.public_sz} ({_bpt:.4f} bits/token) pinned before R1")

    import protocol as _protocol
    tape.prepare_statement()
    statement_digest = _protocol.static_statement_digest(tape.claims, CFG)
    _log(f"trusted statement digest={statement_digest.hex()}")
    _log(f"physical row manifest={json.dumps(tape.layout_manifest, sort_keys=True)}")
    if exact_target:
        lm = tape.layout_manifest
        fresh_capacity = (lm["p1_rows"] + lm["p2_rows"] + lm["p3_rows"] +
                          lm["blind_rows"]) * CFG.ELL
        if lm["weight_rows"] != 49_160_720:
            raise SystemExit(f"target persistent layout changed: {lm['weight_rows']:,} rows")
        if fresh_capacity > 100_000_000_000:
            raise SystemExit(f"target fresh layout exceeds model cap: {fresh_capacity:,} slots")
        raw_open = CFG.T_QUERIES * 8 * (
            lm["weight_rows"] + lm["p1_rows"] + lm["p2_rows"] +
            lm["p3_rows"] + lm["blind_rows"])
        if raw_open * 2.696 > 95_000_000_000:
            raise SystemExit(f"target proof-size cap exceeded: raw={raw_open/1e9:.3f}GB")
        os.environ["LIGERO_TARGET_4H"] = "1"

    if not a.weight_commitment:
        raise SystemExit(
            "production 4h path requires --weight-commitment FILE; create it "
            "once with --enroll-weights FILE (enrollment is not an online proof stage)")
    from core import WeightCommitment
    wc = WeightCommitment.load(a.weight_commitment)
    if a.expected_weight_root is None:
        raise SystemExit("production proof requires --expected-weight-root from trusted enrollment")
    try:
        expected_root = bytes.fromhex(a.expected_weight_root)
    except ValueError as exc:
        raise SystemExit("--expected-weight-root must be hex") from exc
    if len(expected_root) != 32:
        raise SystemExit("--expected-weight-root must encode exactly 32 bytes")
    if wc.root != expected_root:
        raise SystemExit("weight commitment root does not match --expected-weight-root")
    if exact_target:
        if not a.admission_report:
            raise SystemExit("target proof requires --admission-report; refusing an unbounded run")
        import sys as _sys
        _sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "analysis"))
        from production_admission import verify_report
        try:
            _props = torch.cuda.get_device_properties(torch.cuda.current_device())
            _machine = {"device_name": _props.name,
                        "total_memory": int(_props.total_memory),
                        "cuda_runtime": str(torch.version.cuda)}
            _report, _admitted = verify_report(
                a.admission_report, model_root_hex=wc.root.hex(),
                statement_digest_hex=statement_digest.hex(), machine=_machine,
                layout=tape.layout_manifest)
        except (ValueError, OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"production admission REJECT: {exc}") from exc
        _log(f"production admission ACCEPT: simultaneous upper {_admitted:.1f}s")
    t0 = time.time()
    proof = tape.prove(seed=SEED, weight_commitment=wc)
    t_prove = time.time() - t0
    _log(f"prove returned ({t_prove:.1f}s) "
         f"peakGPU={torch.cuda.max_memory_allocated()/2**30:.2f}GB")
    if a.dump_proof:
        import protocol as pr
        from proof_dump import dump_proof
        s_op, s_bind, s_comb, s_col = (
            proof.s_op, proof.s_bind, proof.s_comb, proof.s_col)
        Q = pr.random_columns(s_col, CFG)
        t0 = time.time()
        dump_proof(a.dump_proof, pr.claims_to_json(tape.claims, CFG),
                   {"s_op": s_op.hex(), "s_bind": (s_bind.hex() if s_bind else None),
                    "s_comb": s_comb.hex(), "s_col": s_col.hex()},
                   proof, list(Q), None)
        _log(f"proof dumped to {a.dump_proof} ({time.time()-t0:.1f}s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
