"""Small-field adversarial checks for the two new algebraic seams.

These tests do not replace the Ligero tests; they isolate the identities so a
sign/order regression is visible without a GPU.
"""

import random
import unittest

P = 65537


def inv(x):
    if x % P == 0:
        raise ZeroDivisionError
    return pow(x, P - 2, P)


def compress(beta, rec):
    return sum(b * x for b, x in zip(beta, rec)) % P


def permutation_identity(src, dst, beta, alpha):
    try:
        ls = sum(inv(alpha - compress(beta, r)) for r in src) % P
        rs = sum(inv(alpha - compress(beta, r)) for r in dst) % P
    except ZeroDivisionError:
        return False
    return ls == rs


def routed_contraction(A, W, Y, tau, rho):
    # A[e][k], W[e][k][j], Y[t][j]
    e_n, k_n, j_n, t_n = len(A), len(A[0]), len(rho), len(tau)
    pp = [[sum(rho[j] * W[e][k][j] for j in range(j_n)) % P
           for k in range(k_n)] for e in range(e_n)]
    lhs = sum(A[e][k] * pp[e][k] for e in range(e_n)
              for k in range(k_n)) % P
    rhs = sum(tau[t] * rho[j] * Y[t][j]
              for t in range(t_n) for j in range(j_n)) % P
    return lhs == rhs


def rpm_relations(M, X, W, Y, rho):
    T, E, K, J = len(M), len(M[0]), len(X[0]), len(rho)
    Pp = [[sum(W[e][k][j] * rho[j] for j in range(J)) % P
           for k in range(K)] for e in range(E)]
    Q = [[sum(M[t][e] * Pp[e][k] for e in range(E)) % P
          for k in range(K)] for t in range(T)]
    yr = [sum(Y[t][j] * rho[j] for j in range(J)) % P for t in range(T)]
    return all(sum(X[t][k] * Q[t][k] for k in range(K)) % P == yr[t]
               for t in range(T))


class AlgebraTests(unittest.TestCase):
    def test_record_permutation_accepts_reorder(self):
        beta, alpha = [3, 5, 7, 11], 101
        src = [(0, 0, 0, 4), (0, 1, 0, 9), (1, 0, 0, 2)]
        dst = [src[2], src[0], src[1]]
        self.assertTrue(permutation_identity(src, dst, beta, alpha))

    def test_record_drop_or_mutation_rejects(self):
        beta, alpha = [3, 5, 7, 11], 101
        src = [(0, 0, 0, 4), (0, 1, 0, 9), (1, 0, 0, 2)]
        self.assertFalse(permutation_identity(src, src[:-1], beta, alpha))
        bad = list(src); bad[1] = (0, 1, 0, 10)
        self.assertFalse(permutation_identity(src, bad, beta, alpha))

    def test_routed_projection_accepts_honest_and_rejects_output_error(self):
        rng = random.Random(4)
        T, E, K, J = 3, 2, 4, 3
        route = [0, 1, 0]
        X = [[rng.randrange(P) for _ in range(K)] for _ in range(T)]
        W = [[[rng.randrange(P) for _ in range(J)] for _ in range(K)]
             for _ in range(E)]
        tau = [rng.randrange(1, P) for _ in range(T)]
        rho = [rng.randrange(1, P) for _ in range(J)]
        A = [[sum(tau[t] * X[t][k] for t in range(T) if route[t] == e) % P
              for k in range(K)] for e in range(E)]
        Y = [[sum(X[t][k] * W[route[t]][k][j] for k in range(K)) % P
              for j in range(J)] for t in range(T)]
        self.assertTrue(routed_contraction(A, W, Y, tau, rho))
        Y[1][2] = (Y[1][2] + 1) % P
        self.assertFalse(routed_contraction(A, W, Y, tau, rho))

    def test_rpm_association_accepts_and_rejects(self):
        rng = random.Random(9)
        T, E, K, J = 3, 2, 4, 3
        route = [0, 1, 0]
        M = [[int(route[t] == e) for e in range(E)] for t in range(T)]
        X = [[rng.randrange(P) for _ in range(K)] for _ in range(T)]
        W = [[[rng.randrange(P) for _ in range(J)] for _ in range(K)]
             for _ in range(E)]
        Y = [[sum(X[t][k] * W[route[t]][k][j] for k in range(K)) % P
              for j in range(J)] for t in range(T)]
        rho = [rng.randrange(1, P) for _ in range(J)]
        self.assertTrue(rpm_relations(M, X, W, Y, rho))
        Y[0][0] = (Y[0][0] + 1) % P
        self.assertFalse(rpm_relations(M, X, W, Y, rho))


if __name__ == "__main__":
    unittest.main()
