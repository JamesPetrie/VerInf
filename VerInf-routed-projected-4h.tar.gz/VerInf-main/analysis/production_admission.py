"""Fail-closed admission for the 400B / S=1000 production proof.

The report contains simultaneous 99% upper bounds measured with the exact
GGUF, CUDA kernels, geometry and concurrent I/O path.  Point estimates and a
global calibration multiplier are deliberately rejected.
"""
from __future__ import annotations

import json
import math
import hashlib
from pathlib import Path

from routed_projected_4h_model import SLO, seconds

FORMAT = "verinf-400b-admission-v1"
PROFILE = [48, 128, 1000, 5120, 8192, 202048, 54]
REQUIRED = tuple(seconds(SLO())[0])
# Distribution-free tolerance bound. For 13 stages, Bonferroni gives
# 13 * .99**714 < .01: with simultaneous confidence >99%, every stage's true
# p99 is at most the maximum of its 714 representative raw samples.
MIN_SAMPLES = 714


def source_digest() -> str:
    """Digest the code whose timings the report claims to bound."""
    root = Path(__file__).resolve().parents[1]
    files = []
    suffixes = (".py", ".rs", ".cu", ".cuh", ".cpp", ".h", ".toml", ".lock")
    for base in (root / "prover", root / "demo", root / "verifier" / "src"):
        files.extend(p for p in base.rglob("*") if p.suffix in suffixes)
    files.extend(p for p in (root / "verifier").glob("Cargo.*") if p.is_file())
    h = hashlib.sha256()
    for p in sorted(files):
        rel = str(p.relative_to(root)).encode()
        data = p.read_bytes()
        h.update(len(rel).to_bytes(8, "little")); h.update(rel)
        h.update(len(data).to_bytes(8, "little")); h.update(data)
    return h.hexdigest()


def verify_report(path: str, *, model_root_hex: str, statement_digest_hex: str,
                  machine=None, layout=None):
    report = json.loads(Path(path).read_text(encoding="utf-8"))
    if report.get("format") != FORMAT or report.get("profile") != PROFILE:
        raise ValueError("admission report has wrong format/profile")
    if report.get("prover_source_digest") != source_digest():
        raise ValueError("admission report was measured on different prover/verifier sources")
    if machine is not None and report.get("machine") != machine:
        raise ValueError("admission report was measured on different CUDA hardware/runtime")
    if layout is not None and report.get("layout") != layout:
        raise ValueError("admission report was measured for different physical row counts")
    if (len(report.get("model_root", "")) != 64 or
            report.get("model_root", "").lower() != model_root_hex.lower()):
        raise ValueError("admission report was measured for another model root")
    if (len(report.get("statement_digest", "")) != 64 or
            report.get("statement_digest", "").lower() != statement_digest_hex.lower()):
        raise ValueError("admission report was measured for another statement")
    raw = report.get("raw_samples_seconds", {})
    measured = {}
    for k in REQUIRED:
        xs = raw.get(k)
        if not isinstance(xs, list) or len(xs) < MIN_SAMPLES:
            raise ValueError(f"{k}: need >={MIN_SAMPLES} raw representative samples")
        vals_k = []
        for x in xs:
            if isinstance(x, bool):
                raise ValueError(f"{k}: invalid sample")
            x = float(x)
            if not math.isfinite(x) or x < 0:
                raise ValueError(f"{k}: samples must be finite and non-negative")
            vals_k.append(x)
        measured[k] = max(vals_k)
    caps, _ = seconds(SLO())
    vals = {}
    for k in REQUIRED:
        if isinstance(measured[k], bool):
            raise ValueError(f"invalid numeric bound for {k}")
        x = float(measured[k])
        if not math.isfinite(x) or x < 0:
            raise ValueError(f"bound for {k} must be finite and non-negative")
        vals[k] = x
    bad = {k: (vals[k], caps[k]) for k in REQUIRED if vals[k] > caps[k]}
    if bad:
        raise ValueError(f"stage admission failed (measured,cap): {bad}")
    total = sum(vals.values())
    if not math.isfinite(total) or total > 14_400:
        raise ValueError(f"total p99 upper bound {total:.3f}s exceeds 4h")
    if int(report.get("peak_bytes_upper", 1 << 62)) > 121_000_000_000:
        raise ValueError("peak-memory upper bound exceeds 121GB")
    if int(report.get("free_disk_bytes", 0)) < 100_000_000_000:
        raise ValueError("less than 100GB free for atomic proof output")
    return report, total


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("report")
    p.add_argument("model_root")
    p.add_argument("statement_digest")
    a = p.parse_args()
    _r, total = verify_report(a.report, model_root_hex=a.model_root,
                              statement_digest_hex=a.statement_digest)
    print(f"ADMIT {total:.3f}s ({total/3600:.4f}h)")
